--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.2
-- Dumped by pg_dump version 15.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE pacmann_db;
--
-- Name: pacmann_db; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE pacmann_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_Indonesia.1252';


ALTER DATABASE pacmann_db OWNER TO postgres;

\connect pacmann_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dim_city; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dim_city (
    kota_id integer,
    nama_kota character varying(50),
    latitude real,
    longitude real
);


ALTER TABLE public.dim_city OWNER TO postgres;

--
-- Name: dim_customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dim_customer (
    customer_id text NOT NULL,
    customer_name text,
    customer_address text,
    customer_age double precision,
    customer_phone double precision,
    customer_email text,
    occupation text,
    salary double precision,
    income_type text,
    gender text,
    marital_status text
);


ALTER TABLE public.dim_customer OWNER TO postgres;

--
-- Name: dim_product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dim_product (
    product_id integer,
    brand character varying(50),
    model character varying(50),
    body_type character varying(50),
    year integer,
    price integer
);


ALTER TABLE public.dim_product OWNER TO postgres;

--
-- Name: dim_seller; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dim_seller (
    seller_id double precision NOT NULL,
    seller_name text,
    seller_address text,
    kota_id double precision,
    phone_seller double precision,
    email_seller text
);


ALTER TABLE public.dim_seller OWNER TO postgres;

--
-- Name: fact_application; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fact_application (
    contract_no integer,
    appl_no integer,
    customer_id character varying(50),
    date_bid date,
    bid_price real,
    bid_status character varying(50)
);


ALTER TABLE public.fact_application OWNER TO postgres;

--
-- Name: fact_object; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fact_object (
    appl_no integer,
    seller_id integer,
    product_id integer,
    obj_price real,
    obj_warna character varying(50),
    date_post character varying(50),
    website character varying(50)
);


ALTER TABLE public.fact_object OWNER TO postgres;

--
-- Data for Name: dim_city; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dim_city (kota_id, nama_kota, latitude, longitude) FROM stdin;
\.
COPY public.dim_city (kota_id, nama_kota, latitude, longitude) FROM '$$PATH$$/3339.dat';

--
-- Data for Name: dim_customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dim_customer (customer_id, customer_name, customer_address, customer_age, customer_phone, customer_email, occupation, salary, income_type, gender, marital_status) FROM stdin;
\.
COPY public.dim_customer (customer_id, customer_name, customer_address, customer_age, customer_phone, customer_email, occupation, salary, income_type, gender, marital_status) FROM '$$PATH$$/3342.dat';

--
-- Data for Name: dim_product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dim_product (product_id, brand, model, body_type, year, price) FROM stdin;
\.
COPY public.dim_product (product_id, brand, model, body_type, year, price) FROM '$$PATH$$/3340.dat';

--
-- Data for Name: dim_seller; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dim_seller (seller_id, seller_name, seller_address, kota_id, phone_seller, email_seller) FROM stdin;
\.
COPY public.dim_seller (seller_id, seller_name, seller_address, kota_id, phone_seller, email_seller) FROM '$$PATH$$/3343.dat';

--
-- Data for Name: fact_application; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fact_application (contract_no, appl_no, customer_id, date_bid, bid_price, bid_status) FROM stdin;
\.
COPY public.fact_application (contract_no, appl_no, customer_id, date_bid, bid_price, bid_status) FROM '$$PATH$$/3338.dat';

--
-- Data for Name: fact_object; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fact_object (appl_no, seller_id, product_id, obj_price, obj_warna, date_post, website) FROM stdin;
\.
COPY public.fact_object (appl_no, seller_id, product_id, obj_price, obj_warna, date_post, website) FROM '$$PATH$$/3341.dat';

--
-- Name: dim_customer dim_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dim_customer
    ADD CONSTRAINT dim_customer_pkey PRIMARY KEY (customer_id);


--
-- Name: dim_seller dim_seller_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dim_seller
    ADD CONSTRAINT dim_seller_pkey PRIMARY KEY (seller_id);


--
-- PostgreSQL database dump complete
--

